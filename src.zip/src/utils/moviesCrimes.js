export const MOVIESCRIME = [
  {
    id: "1",
    name: "Dark Knight",
    moviesURL: require("../img/movies/dark-knight.png"),
  },
  {
    id: "2",
    name: "Sherlock Holmes",
    moviesURL: require("../img/movies/sherlock_holmes.png"),
  },
  {
    id: "3",
    name: "Dark Knight",
    moviesURL: require("../img/movies/dark-knight.png"),
  },
];
