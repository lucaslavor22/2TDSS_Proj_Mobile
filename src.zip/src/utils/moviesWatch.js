export const MOVIESWATCH = [
  {
    id: "1",
    name: "English",
    moviesURL: require("../img/movies/English.png"),
  },
  {
    id: "2",
    name: "Hindi",
    moviesURL: require("../img/movies/Hindi.png"),
  },
  {
    id: "3",
    name: "Telugu",
    moviesURL: require("../img/movies/Telugu.png"),
  },
];
