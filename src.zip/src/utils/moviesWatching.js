export const MOVIESWATCHING = [
  {
    id: "1",
    name: "Wheel Of Time",
    moviesURL: require("../img/movies/wheel_of_time.png"),
  },
  {
    id: "2",
    name: "Inception",
    moviesURL: require("../img/movies/inception.png"),
  },
  {
    id: "3",
    name: "Inception",
    moviesURL: require("../img/movies/inception.png"),
  },
];
