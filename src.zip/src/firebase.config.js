import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyDI-vhQl4RxCwxzvymshGuqbjhVTgoTLKE",
  authDomain: "pluemovies-73d47.firebaseapp.com",
  projectId: "pluemovies-73d47",
  storageBucket: "pluemovies-73d47.appspot.com",
  messagingSenderId: "932623523243",
  appId: "1:932623523243:web:13a3a305632345eb2d86ee"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
