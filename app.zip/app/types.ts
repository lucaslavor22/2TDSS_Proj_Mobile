export type RootStackParamList = {
    Login: undefined;
    Catalog: undefined;
  };
  