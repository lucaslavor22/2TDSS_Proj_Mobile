import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const CatalogScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text>Catalog of Movies and Series</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default CatalogScreen;
