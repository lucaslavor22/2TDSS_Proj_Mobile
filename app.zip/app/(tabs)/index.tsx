import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import CatalogScreen from './CatalogScreen';

const Tab = createBottomTabNavigator();

export default function Tabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Catalog" component={CatalogScreen} />
      {/* Adicione outras telas do catálogo aqui */}
    </Tab.Navigator>
  );
}
